class Routes {
  Routes._();

  static const user = '/user/';
  static const navBarView = '/navBarView/';
  static const home = '/home/';
  static const categoryView = '/categoryView/';
  static const whishlistView = '/whishlistView/';
  static const profileView = '/profileView/';
  static const language = '/language/';
  static const subCategory = '/subCategory/';
  static const categoryWiseProductView = "/categoryWiseProductView/";
  static const cartScreen = "/cartScreen/";
}

import 'package:get/get.dart';

class WishlistBindings extends Bindings {
  @override
  void dependencies() {}
}

// import 'package:get/get.dart';
// import 'package:ebazaar/app/featuers/category/controller/category_tree_controller.dart';

// class CategoryTreeControllerBindings extends Bindings {
//   @override
//   void dependencies() {
//     Get.lazyPut(() => CategoryTreeController());
//   }
// }
